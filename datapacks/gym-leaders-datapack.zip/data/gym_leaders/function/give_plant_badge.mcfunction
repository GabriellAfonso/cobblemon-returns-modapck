give @s pokebadges:plant_kalos_badge
