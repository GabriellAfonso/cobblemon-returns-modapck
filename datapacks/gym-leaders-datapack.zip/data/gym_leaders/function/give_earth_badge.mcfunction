give @s pokebadges:earth_kanto_badge
