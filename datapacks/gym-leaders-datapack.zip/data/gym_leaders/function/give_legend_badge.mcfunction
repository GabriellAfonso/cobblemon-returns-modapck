give @s pokebadges:legend_unova_badge
