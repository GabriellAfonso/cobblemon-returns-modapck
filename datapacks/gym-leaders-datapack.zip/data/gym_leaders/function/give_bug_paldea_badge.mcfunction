give @s pokebadges:bug_paldea_badge
