give @s pokebadges:grass_paldea_badge
