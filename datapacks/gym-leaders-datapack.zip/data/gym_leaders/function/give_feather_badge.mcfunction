give @s pokebadges:feather_hoenn_badge
