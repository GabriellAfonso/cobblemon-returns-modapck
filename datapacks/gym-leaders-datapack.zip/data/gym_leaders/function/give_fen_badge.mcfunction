give @s pokebadges:fen_sinnoh_badge
