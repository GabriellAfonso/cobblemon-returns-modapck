give @s pokebadges:fairy_kalos_badge
