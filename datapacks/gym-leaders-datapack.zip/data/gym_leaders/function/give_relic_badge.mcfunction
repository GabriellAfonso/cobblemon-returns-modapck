give @s pokebadges:relic_sinnoh_badge
