give @s pokebadges:normal_paldea_badge
