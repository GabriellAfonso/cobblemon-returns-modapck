give @s pokebadges:ice_galar_badge
