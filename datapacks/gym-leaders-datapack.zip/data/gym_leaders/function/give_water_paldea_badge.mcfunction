give @s pokebadges:water_paldea_badge
