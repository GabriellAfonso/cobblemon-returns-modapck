give @s pokebadges:dragon_galar_badge
