give @s pokebadges:electric_paldea_badge
