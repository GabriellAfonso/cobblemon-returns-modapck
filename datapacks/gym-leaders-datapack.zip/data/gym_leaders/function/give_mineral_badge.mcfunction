give @s pokebadges:mineral_johto_badge
