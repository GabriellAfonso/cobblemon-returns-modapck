give @s pokebadges:cobble_sinnoh_badge
