give @s pokebadges:rock_galar_badge
