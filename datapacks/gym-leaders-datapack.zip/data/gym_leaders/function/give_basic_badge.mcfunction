give @s pokebadges:basic_unova_badge
