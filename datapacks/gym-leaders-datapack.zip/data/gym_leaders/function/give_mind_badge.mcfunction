give @s pokebadges:mind_hoenn_badge
