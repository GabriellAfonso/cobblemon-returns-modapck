give @s pokebadges:knuckle_hoenn_badge
