give @s pokebadges:rain_hoenn_badge
