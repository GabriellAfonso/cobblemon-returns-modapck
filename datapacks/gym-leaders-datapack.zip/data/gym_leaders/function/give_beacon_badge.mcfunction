give @s pokebadges:beacon_sinnoh_badge
