give @s pokebadges:soul_kanto_badge
