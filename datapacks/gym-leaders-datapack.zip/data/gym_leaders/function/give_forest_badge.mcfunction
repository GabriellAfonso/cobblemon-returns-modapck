give @s pokebadges:forest_sinnoh_badge
