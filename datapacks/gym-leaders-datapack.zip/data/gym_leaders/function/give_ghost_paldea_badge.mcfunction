give @s pokebadges:ghost_paldea_badge
