give @s pokebadges:quake_unova_badge
