give @s pokebadges:voltage_kalos_badge
