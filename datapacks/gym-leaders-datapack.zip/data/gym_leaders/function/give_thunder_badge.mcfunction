give @s pokebadges:thunder_kanto_badge
