give @s pokebadges:mine_sinnoh_badge
