give @s pokebadges:bug_kalos_badge
