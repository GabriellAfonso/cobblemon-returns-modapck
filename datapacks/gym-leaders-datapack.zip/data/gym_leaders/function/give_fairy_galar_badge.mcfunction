give @s pokebadges:fairy_galar_badge
