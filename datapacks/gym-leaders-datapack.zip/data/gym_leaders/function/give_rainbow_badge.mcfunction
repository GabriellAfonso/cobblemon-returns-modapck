give @s pokebadges:rainbow_kanto_badge
