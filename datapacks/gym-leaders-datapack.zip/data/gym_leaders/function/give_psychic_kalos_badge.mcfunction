give @s pokebadges:psychic_kalos_badge
