give @s pokebadges:stone_hoenn_badge
