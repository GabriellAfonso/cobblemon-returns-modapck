give @s pokebadges:balance_hoenn_badge
