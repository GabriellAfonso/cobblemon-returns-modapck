give @s pokebadges:heat_hoenn_badge
