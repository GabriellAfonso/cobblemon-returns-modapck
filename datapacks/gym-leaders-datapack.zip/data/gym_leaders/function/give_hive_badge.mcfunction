give @s pokebadges:hive_johto_badge
