give @s pokebadges:ghost_galar_badge
