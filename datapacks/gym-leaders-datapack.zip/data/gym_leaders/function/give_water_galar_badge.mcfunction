give @s pokebadges:water_galar_badge
