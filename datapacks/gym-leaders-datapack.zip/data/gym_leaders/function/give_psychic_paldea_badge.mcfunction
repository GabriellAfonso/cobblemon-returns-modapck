give @s pokebadges:psychic_paldea_badge
