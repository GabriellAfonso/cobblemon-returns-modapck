give @s pokebadges:cliff_kalos_badge
