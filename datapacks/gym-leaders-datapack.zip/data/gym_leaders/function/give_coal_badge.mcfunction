give @s pokebadges:coal_sinnoh_badge
