give @s pokebadges:dark_galar_badge
