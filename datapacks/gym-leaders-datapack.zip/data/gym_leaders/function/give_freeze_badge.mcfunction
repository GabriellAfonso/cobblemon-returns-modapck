give @s pokebadges:freeze_unova_badge
