give @s pokebadges:dynamo_hoenn_badge
