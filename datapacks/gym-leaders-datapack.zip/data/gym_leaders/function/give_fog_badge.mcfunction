give @s pokebadges:fog_johto_badge
