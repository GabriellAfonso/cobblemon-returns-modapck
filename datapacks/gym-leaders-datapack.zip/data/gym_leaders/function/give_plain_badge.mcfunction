give @s pokebadges:plain_johto_badge
