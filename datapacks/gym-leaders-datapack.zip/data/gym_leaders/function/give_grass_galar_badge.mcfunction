give @s pokebadges:grass_galar_badge
