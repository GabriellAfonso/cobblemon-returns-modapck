give @s pokebadges:fire_galar_badge
