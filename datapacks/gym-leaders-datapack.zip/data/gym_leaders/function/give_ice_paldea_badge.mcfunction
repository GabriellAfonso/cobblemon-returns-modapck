give @s pokebadges:ice_paldea_badge
