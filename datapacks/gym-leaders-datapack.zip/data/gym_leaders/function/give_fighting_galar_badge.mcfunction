give @s pokebadges:fighting_galar_badge
