give @s pokebadges:trio_unova_badge
